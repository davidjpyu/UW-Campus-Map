package graph;

import java.util.*;

/**
 * Represents a mutable directed labeled graph as a collection of nodes and one-way edges, and no 2 edges with the
 * same parent and child nodes will have the same edge label
 * @param <N> A type parameter to make node data generic
 * @param <E> A type parameter to make edge label generic
 */
public class DirectedLabeledGraph <N, E> {
    // AF(this) = nodeMap
    // RI: nodeMap != null;
    //      for i to be any elements of nodeMap.KeySet(), it is not allowed that for any 0 <= j,k < nodeMap.get(i).size()
    //      where j != k, (nodeMap.get(i).get(j).getChild().equals(nodeMap.get(i).get(k).getChild()) &&
    //      nodeMap.get(i).get(j).getLabel().equals(nodeMap.get(i).get(k).getLabel()))
    private HashMap<N, HashSet<DLGEdge>> nodeMap;

    /**
     * Creates a new initially empty DirectedLabeledGraph.
     */
    public DirectedLabeledGraph() {
        nodeMap = new HashMap<>();
        checkRep();
    }

    /**
     * Adds a node represented by nodeName to this graph.
     * @param data A data that represent data of a node to be added to this graph
     * @throws IllegalArgumentException if there is a node in the graph with identical data
     * @spec.modifies this
     * @spec.effects Add a node to the graph
     */
    public void addNode(N data) {
        checkRep();
        if (nodeMap.containsKey(data)) {
            throw new IllegalArgumentException("addNode: there is a node in the graph with identical data: ");
        }
        nodeMap.put(data, new HashSet<>());
        checkRep();
    }

    /**
     * Adds an edge represented by edgename to this graph.
     * @param parentNodeName A data that represent a node to be regarded as parent for this edge of the graph
     * @param childNodeName A data that represent a node to be regarded as child for this edge of the graph
     * @param edgeLabel A data that represent an edge to be added to this graph
     * @throws IllegalArgumentException if there exist an edge in the graph with identical parent, child, and label,
     *                                  or if parentNode or childNode does not exist in this graph
     * @spec.modifies this
     * @spec.effects Add an edge to the graph
     */
    public void addEdge(N parentNodeName, N childNodeName, E edgeLabel) {
        checkRep();
        if (!(nodeMap.containsKey(parentNodeName) && nodeMap.containsKey(childNodeName))) {
            throw new IllegalArgumentException("addEdge: parentNode or childNode does not exist in this graph");
        }
        else if (containsEdge(parentNodeName, childNodeName, edgeLabel)) {
            throw new IllegalArgumentException("addEdge: exist edge with identical parent, child, and label");
        }

        nodeMap.get(parentNodeName).add(new DLGEdge(parentNodeName, childNodeName, edgeLabel));
        checkRep();
    }

    /**
     * Checks whether this graph contains a node with specified data
     * @param data A data that specify a node to check
     * @return true if node is contained in the graph, false if not contained
     */
    public boolean containsNode(N data) {
        checkRep();
        return nodeMap.containsKey(data);
    }

    /**
     * Checks whether the graph contains an edge with specified parent and child nodes, and specified label
     * @param parent A data that specify a parent node of the edge to check
     * @param child A data that specify a child node of the edge to check
     * @param label A data that specify a label of the edge to check
    * @throws IllegalArgumentException if parentNode or childNode does not exist in this graph
     * @return true if edge is contained in this graph, false if not contained
     */
    public boolean containsEdge(N parent, N child, E label) {
        checkRep();
        if (!(nodeMap.containsKey(parent) && nodeMap.containsKey(child))) {
            throw new IllegalArgumentException("parentNode or childNode not exist");
        }
        HashSet<DLGEdge> set = nodeMap.get(parent);
        DLGEdge checkingEdge = new DLGEdge(parent, child, label);
        for (DLGEdge i:set) {
            if(i.equals(checkingEdge)) {
                checkRep();
                return true;
            }
        }
        checkRep();
        return false;
    }

    /**
     * Returns a set of nodes in this graph.
     * @return A set of DLGNode in this graph
     */
    public Set<N> getNodeList() {
        checkRep();
        return nodeMap.keySet();
    }

    /**
     * Returns a set of edges in this graph that have a specified parent node.
     * @param parent A data that represent a specified parent node of this graph
     * @throws IllegalArgumentException if parent node does not exist in the graph
     * @return A set of DLGEdge in this graph that have a specified parent node
     */
    public Set<DLGEdge> getEdgeList(N parent) {
        checkRep();
        if (!nodeMap.containsKey(parent)) {
            throw new IllegalArgumentException("parent node not exists");
        }
        checkRep();
        return nodeMap.get(parent);
    }

    // check if RI holds
    private void checkRep() {
//        if (nodeMap == null) {
//            throw new RuntimeException("checkRep of DirectedLabeledGraph failure: nodeMap = null");
//        }
//        for (N i:nodeMap.keySet()) {
//            for (DLGEdge j:nodeMap.get(i)) {
//                for (DLGEdge k:nodeMap.get(i)) {
//                    if (j != k && j.equals(k)) {
//                        throw new RuntimeException("checkRep of DirectedLabeledGraph failure: duplicate Edges");
//                    }
//                }
//            }
//        }
    }

    /**
     * Represents a immutable one-way edge that indicates one node is reachable from another in a graph
     */
    public class DLGEdge {
        // AF(this) = parent + child + label
        // RI: parent != null, child != null, label != null;
        private final N parent;
        private final N child;
        private final E label;

        /**
         * Creates an edge for directed graph from one given node to another
         * @param parent gives a data representing the node that this edge goes from
         * @param child gives a data representing the node that this edge goes to
         * @param label edge label that contains information about an edge
         * @spec.requires parent != null and child != null
         */
        public DLGEdge (N parent, N child, E label) {
            this.parent = parent;
            this.child = child;
            this.label = label;
        }

        /**
         * Returns the data representing the parent node in this edge
         * @return A data representing the parent node in this edge
         */
        public N getParent() {
            checkRep();
            return parent;
        }

        /**
         * Returns the data representing the child node in this edge
         * @return A data representing the child node in this edge
         */
        public N getChild() {
            checkRep();
            return child;
        }

        /**
         * Returns the label of this edge
         * @return A data that represent the label of this edge
         */
        public E getLabel() {
            checkRep();
            return label;
        }

        @Override
        public boolean equals(Object o) {
            checkRep();
            if (!(o instanceof DirectedLabeledGraph<?, ?>.DLGEdge)) {
                checkRep();
                return false;
            }
            DirectedLabeledGraph<?, ?>.DLGEdge other = (DirectedLabeledGraph<?, ?>.DLGEdge) o;
            checkRep();
            return this.parent.equals(other.parent) && this.child.equals(other.child) && this.label.equals(other.label);
        }

        @Override
        public int hashCode() {
            checkRep();
            return (parent.hashCode() + 1) + 2 * (child.hashCode() + 1) + 3 * (label.hashCode() + 1);
        }

        // check if RI holds
        private void checkRep() {
//            if (parent == null || child == null || label == null) {
//                throw new RuntimeException("checkRep of DLGEdge failure: node = null");
//            }
        }
    }
}
