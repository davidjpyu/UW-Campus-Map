package graph.junitTests;

import graph.*;
import org.junit.Test;

import org.junit.Rule;
import org.junit.rules.Timeout;

import static org.junit.Assert.*;

/**
 * DirectedLabeledGraphTest is a glassbox test of the DirectedLabeledGraph class.
 */
public class DirectedLabeledGraphTest {
    @Rule public Timeout globalTimeout = Timeout.seconds(10); // 10 seconds max per method tested

    /** Test containsNode(). */
    @Test
    public void testContainsNode() {
        DirectedLabeledGraph<String, String> g1 = new DirectedLabeledGraph<>();
        // empty node
        assertFalse(g1.containsNode("n1"));

        // one node
        g1.addNode("n1");
        assertTrue(g1.containsNode("n1"));
        assertFalse(g1.containsNode("n2"));

        // two node
        g1.addNode("n2");
        assertTrue(g1.containsNode("n1"));
        assertTrue(g1.containsNode("n2"));
        assertFalse(g1.containsNode("n3"));
    }

    /** Test containsEdge(). */
    @Test
    public void testContainsEdge() {
        DirectedLabeledGraph<String, String> g1 = new DirectedLabeledGraph<>();
        g1.addNode("n1");
        g1.addNode("n2");
        g1.addNode("n3");

        // empty edge
        assertFalse(g1.containsEdge("n1", "n2", "e12"));

        // one edge
        g1.addEdge("n1", "n2", "e12");
        assertTrue(g1.containsEdge("n1", "n2", "e12"));
        assertFalse(g1.containsEdge("n1", "n3", "e13"));

        // two edges
        g1.addEdge("n1", "n3", "e13");
        assertTrue(g1.containsEdge("n1", "n2", "e12"));
        assertTrue(g1.containsEdge("n1", "n3", "e13"));
        assertFalse(g1.containsEdge("n2", "n3", "e23"));
    }

    /** Test containsEdge() error case: parentNode does not exist in this graph */
    @Test(expected = IllegalArgumentException.class)
    public void testContainsEdgeError1() {
        DirectedLabeledGraph<String, String> g1 = new DirectedLabeledGraph<>();
        g1.addNode("n1");
        g1.containsEdge("n2", "n1", "e21");
    }

    /** Test containsEdge() error case: childNode does not exist in this graph */
    @Test(expected = IllegalArgumentException.class)
    public void testContainsEdgeError2() {
        DirectedLabeledGraph<String, String> g1 = new DirectedLabeledGraph<>();
        g1.addNode("n1");
        g1.containsEdge("n1", "n2", "e12");
    }

    /** Test addNode() error case: there is a node in the graph with identical data already */
    @Test(expected = IllegalArgumentException.class)
    public void testAddNode() {
        DirectedLabeledGraph<String, String> g1 = new DirectedLabeledGraph<>();
        g1.addNode("n1");
        g1.addNode("n1");
    }

    /** Test addEdge() error case: there exist an edge in the graph with identical parent, child, and label */
    @Test(expected = IllegalArgumentException.class)
    public void testAddEdgeError1() {
        DirectedLabeledGraph<String, String> g1 = new DirectedLabeledGraph<>();
        g1.addNode("n1");
        g1.addNode("n2");
        g1.addEdge("n1", "n2", "e12");
        g1.addEdge("n1", "n2", "e12");
    }

    /** Test addEdge() error case: parentNode or childNode does not exist in this graph */

    @Test(expected = IllegalArgumentException.class)
    public void testAddEdgeError2() {
        DirectedLabeledGraph<String, String> g1 = new DirectedLabeledGraph<>();
        g1.addNode("n1");
        g1.addEdge("n1", "n2", "e12");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddEdgeError3() {
        DirectedLabeledGraph<String, String> g1 = new DirectedLabeledGraph<>();
        g1.addNode("n2");
        g1.addEdge("n1", "n2", "e12");
    }


    /** Test getEdgeList() error case: parent node does not exist in the graph */
    @Test(expected = IllegalArgumentException.class)
    public void testGetEdgeList() {
        DirectedLabeledGraph<String, String> g1 = new DirectedLabeledGraph<>();
        g1.getEdgeList("n1");
    }

    /** special case: cycle, test if containsEdge still works */
    @Test
    public void cycleCase() {
        DirectedLabeledGraph<String, String> g1 = new DirectedLabeledGraph<>();
        g1.addNode("n1");
        g1.addNode("n2");
        g1.addNode("n3");
        g1.addEdge("n1", "n2", "e");
        g1.addEdge("n2", "n3", "e");
        g1.addEdge("n3", "n1", "e");
        assertFalse(g1.containsEdge("n1", "n3", "e"));
        assertFalse(g1.containsEdge("n1", "n1", "e"));
    }

    /** special case: islands, test if containsNode still works */
    @Test
    public void islandCase() {
        DirectedLabeledGraph<String, String> g1 = new DirectedLabeledGraph<>();
        g1.addNode("n1");
        g1.addNode("n2");
        g1.addNode("n3");
        g1.addNode("n4");
        g1.addEdge("n1", "n2", "e");
        g1.addEdge("n2", "n3", "e");
        g1.addEdge("n3", "n1", "e");
        assertTrue(g1.containsNode("n4"));
    }
}
