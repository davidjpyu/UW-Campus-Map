package graph.junitTests;

import graph.*;
import org.junit.Test;
import static org.junit.Assert.*;

import org.junit.Rule;
import org.junit.rules.Timeout;

/**
 * DLGEdgeTest is a glassbox test of the DLGEdge class.
 */
public class DLGEdgeTest {
    @Rule public Timeout globalTimeout = Timeout.seconds(10); // 10 seconds max per method tested

    /** Test creating Edges. */
    @Test
    public void testCreation() {
        DirectedLabeledGraph<String, String> g1 = new DirectedLabeledGraph<>();

        DirectedLabeledGraph.DLGEdge e02 = g1.new DLGEdge("", "node2", ""); // empty label
        DirectedLabeledGraph.DLGEdge e00 = g1.new DLGEdge("", "", "label00"); // edge to node itself
        DirectedLabeledGraph.DLGEdge e12 = g1.new DLGEdge("node1", "node2", "label12"); // something for label
    }

    // Some examples used by the tests below.
    private static DirectedLabeledGraph<String, String> g1 = new DirectedLabeledGraph<>();

    private String n0 = "";
    private String n1 = "node1";
    private String n2 = "node2";

    private static DirectedLabeledGraph.DLGEdge e02 = g1.new DLGEdge("", "node2", ""); // empty label
    private static DirectedLabeledGraph.DLGEdge e00 = g1.new DLGEdge("", "", "label00"); // edge to node itself
    private static DirectedLabeledGraph.DLGEdge e12 = g1.new DLGEdge("node1", "node2", "label12"); // something for label

    /** Test getParent(). */
    @Test
    public void testGetParent() {
        assertEquals(e02.getParent(), n0);
        assertEquals(e00.getParent(), n0);
        assertEquals(e12.getParent(), n1);
    }

    /** Test getChild(). */
    @Test
    public void testGetChild() {
        assertEquals(e02.getChild(), n2);
        assertEquals(e00.getChild(), n0);
        assertEquals(e12.getChild(), n2);
    }

    /** Test getLabel(). */
    @Test
    public void testGetLabel() {
        assertEquals(e02.getLabel(), "");
        assertEquals(e00.getLabel(), "label00");
        assertEquals(e12.getLabel(), "label12");
    }
}
