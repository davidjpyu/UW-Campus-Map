package pathfinder;

import graph.DirectedLabeledGraph;
import pathfinder.datastructures.Path;

import java.util.*;

/**
 * This represents an immutable Dijkstra's Algorithm applied on a particualr graph, which finds a minimum-cost path
 * between two given nodes in a graph.
 * @param <N> A type parameter to make Dijkstra's Algorithm generic on its nodes.
 */
public class Dijkstras_Algorithm <N> {
    // AF(this) = graph that is applied of Dijkstra's Algorithm
    // RI: this.graph != null
    private final DirectedLabeledGraph<N, Double> graph;

    private Comparator<Path<N>> compPath = new Comparator<>() {
        @Override
        public int compare(Path<N> o1, Path<N> o2) {
            return Double.compare(o1.getCost(), o2.getCost());
        }
    };

    /**
     * Creates the Dijkstra's Algorithm applied on a given graph
     * @param graph The graph to apply on Dijkstra's Algorithm
     */
    public Dijkstras_Algorithm (DirectedLabeledGraph<N, Double> graph) {
        this.graph = graph;
        checkRep();
    }

    /**
     * Find a minimum-cost path between two given nodes of this using Dijkstra's Algorithm
     *
     * @param start The start node of the path
     * @param dest Then end node of the path
     * @return A path from start node to end node that has minimum cost.
     *          Or null if no path is found.
     */
    public Path<N> findMinCost(N start, N dest) {
        checkRep();
        Set<N> finished = new HashSet<>();
        PriorityQueue<Path<N>> active = new PriorityQueue<>(compPath);
        active.add(new Path<>(start));

        Path<N> minPath;
        N minDest;

        while (!active.isEmpty()) {
            minPath = active.remove();
            minDest = minPath.getEnd();

            if (minDest.equals(dest)) {
                checkRep();
                return minPath;
            }
            if (finished.contains(minDest)) {
                continue;
            }

            Path<N> newPath;
            for (DirectedLabeledGraph<N, Double>.DLGEdge e : graph.getEdgeList(minDest)) {
                if (!finished.contains(e.getChild())) {
                    newPath = minPath.extend(e.getChild(), e.getLabel());
                    active.add(newPath);
                }
            }
            finished.add(minDest);
        }
        checkRep();
        return null;
    }

    // check if RI holds
    private void checkRep() {
        if(graph == null) {
            throw new RuntimeException("checkRep of Dijkstras_Algorithm failure: graph = null");
        }
    }
}
