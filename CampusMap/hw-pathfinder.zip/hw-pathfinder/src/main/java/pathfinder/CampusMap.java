/*
 * Copyright (C) 2022 Kevin Zatloukal.  All rights reserved.  Permission is
 * hereby granted to students registered for University of Washington
 * CSE 331 for use solely during Spring Quarter 2022 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.  Instructors
 * interested in reusing these course materials should contact the
 * author.
 */

package pathfinder;

import graph.DirectedLabeledGraph;
import pathfinder.datastructures.*;
import pathfinder.parser.CampusBuilding;
import pathfinder.parser.CampusPath;
import pathfinder.parser.CampusPathsParser;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This represents an immutable class, a Campus map, that implements ModelAPI and returns information needed by
 * controller.
 */
public class CampusMap implements ModelAPI {
    // AF(this) = graph - the Map of all direct paths + buildings - all buildings of the campus.
    // RI: this.graph != null, this.buildings != null, this.map != null, this.algo != null;
    private final List<CampusBuilding> buildings;
    private final DirectedLabeledGraph<Point, Double> graph;
    private final Map<String, String> map;
    private final Dijkstras_Algorithm<Point> algo;

    /**
     * Creates a new CampusMap that process given files into data to be stored
     */
    public CampusMap () {
        buildings = CampusPathsParser.parseCampusBuildings("campus_buildings.csv");
        List<CampusPath> paths = CampusPathsParser.parseCampusPaths("campus_paths.csv");
        graph = new DirectedLabeledGraph<>();
        Point startPoint;
        Point endPoint;
        for (CampusPath i : paths) {
            startPoint = new Point(i.getX1(), i.getY1());
            endPoint = new Point(i.getX2(), i.getY2());
            if (!graph.containsNode(startPoint)) {
                graph.addNode(startPoint);
            }
            if (!graph.containsNode(endPoint)) {
                graph.addNode(endPoint);
            }
            graph.addEdge(startPoint, endPoint, i.getDistance());
        }
        algo = new Dijkstras_Algorithm<>(graph);

        map = new HashMap<>();
        for (CampusBuilding i : buildings) {
            map.put(i.getShortName(), i.getLongName());
        }

        checkRep();
    }

    @Override
    public boolean shortNameExists(String shortName) {
        checkRep();
        return map.containsKey(shortName);
    }

    @Override
    public String longNameForShort(String shortName) {
        checkRep();
        if (!map.containsKey(shortName)) {
            checkRep();
            throw new IllegalArgumentException("shortName does not exist in the map");
        }
        checkRep();
        return map.get(shortName);
    }

    @Override
    public Map<String, String> buildingNames() {
        checkRep();
        Map<String, String> mapCopy = new HashMap<>(map);
        checkRep();
        return mapCopy;
    }

    @Override
    public Path<Point> findShortestPath(String startShortName, String endShortName) {
        checkRep();
        if ((!map.containsKey(startShortName)) || (!map.containsKey(endShortName))) {
            checkRep();
            throw new IllegalArgumentException("startShortName or endShortName does not exist in the map");
        }
        double startX = 0;
        double startY = 0;
        double endX = 0;
        double endY = 0;
        for (CampusBuilding i : buildings) {
            if (i.getShortName().equals(startShortName)) {
                startX = i.getX();
                startY = i.getY();
            }
            if (i.getShortName().equals(endShortName)) {
                endX = i.getX();
                endY = i.getY();
            }
        }
        Point start = null;
        Point dest = null;
        for (Point i : graph.getNodeList()) {
            if (i.getX() == startX && i.getY() == startY) {
                start = i;
            }
            if (i.getX() == endX && i.getY() == endY) {
                dest = i;
            }
        }

        if(start == null || dest == null) {
            checkRep();
            throw new IllegalArgumentException("startBuilding or endBuilding are null");
        }

        checkRep();
        return algo.findMinCost(start, dest);
    }

    // check if RI holds
    private void checkRep() {
        if (this.graph == null || this.buildings == null || this.map == null || this.algo == null) {
            throw new RuntimeException("checkRep of CampusMap failure");
        }
    }
}
